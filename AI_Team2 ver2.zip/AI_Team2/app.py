# app.py
from flask import Flask, render_template

#Flask 객체 인스턴스 생성
app = Flask(__name__)
# static폴더로 지정하고 싶으면
# app = Flask(__name__, static_folder=./static/')


@app.route('/') 
def index():
        return render_template('index.html')

@app.route('/templates/home.html') 
def link1():
        return render_template('home.html')

@app.route('/templates/about.html') 
def link2():
        return render_template('about.html')

@app.route('/templates/recognition.html') 
def link3():
        return render_template('recognition.html')

@app.route('/templates/update.html') 
def link4():
        return render_template('update.html')

  
if __name__=="__main__":
  app.run(debug=True)  
  # host 등을 직접 지정하고 싶다면
  # app.run(host="127.0.0.1", port="5000", debug=True)
